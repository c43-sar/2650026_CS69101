# Lab Assignment 4: Red-Black Tree

## Files
- `LAB4_RedBlackTree_completed.ipynb`: completed notebook with the deletion implementation, invariant checks, experiments, and graph cells.
- `lab4_data/input.txt`: small example input used to verify the notebook. Replace it with the assignment's actual input data before submission.
- `lab4_data/output.txt`: output generated for the example input above after deleting the first four distinct input keys.
- `lab4_data/task*.png`: the 10 generated Task 6, Task 7, and Task 8 graphs.

## Running
Open the notebook with this folder as the working directory and run all cells from top to bottom. The notebook reads `lab4_data/input.txt` when present. If no `input.txt` is present, it uses the generated demo data in `lab4_data/input0.txt`. Final contents are written to `lab4_data/output.txt`; graph PNGs are also saved in `lab4_data/`.

Operation costs are reported as iteration/computation counts, not wall-clock time. All plots use linear scales. The 50,000-node size is optional and is disabled by default.
